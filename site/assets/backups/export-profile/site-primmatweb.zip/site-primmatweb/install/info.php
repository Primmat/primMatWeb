<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "web primmatu", 
	'summary' => "by Josef Fajkus", 
	'screenshot' => "customlogo.png"
	);
