


<?php

include('includes/header.php');

?>


<?php
echo "<div class='uk-container uk-container-xlarge contaktContainer'>";
echo "<div>";
echo kontakt ($page);
echo "</div>";
echo "</div>";

include('includes/footer.php');

?>