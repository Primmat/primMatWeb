<?php

include("includes/header.php");

?>


<?php

echo childrenPagesButtons ($page);

include("includes/footer.php");
?>