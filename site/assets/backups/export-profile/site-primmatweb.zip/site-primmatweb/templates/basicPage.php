<?php

include("includes/header.php");

?>


<?php
echo basicHeading ($page);
echo euProjectsPage($page);

include("includes/footer.php");

?>