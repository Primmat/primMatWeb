<?php

include("includes/header.php");

echo oborPage ($page);

include("includes/footer.php");

?>